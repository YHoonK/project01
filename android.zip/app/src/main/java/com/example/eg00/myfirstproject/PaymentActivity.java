package com.example.eg00.myfirstproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class PaymentActivity extends AppCompatActivity {
    TextView textView4;
    ArrayList<String> passedList;
    ArrayList<String> list;
    ArrayList<String> orderList;
    ArrayAdapter<String> adapter;
    ListView listView;

    Button btn_call;
    Button btn_touch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        textView4 = findViewById(R.id.textView4);
        listView = findViewById(R.id.listView);

        list = new ArrayList<>();

        Intent passedIntent = getIntent();
        passedList = new ArrayList<>();
        passedList = passedIntent.getStringArrayListExtra("sendList");

        for (int i = 0; i < passedList.size(); i++) {
            list.add(passedList.get(i));
        }

        adapter = new ArrayAdapter<>(getApplication(), android.R.layout.simple_list_item_multiple_choice, list);

        listView.setAdapter(adapter);


        orderList = new ArrayList<>();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = String.valueOf(parent.getItemAtPosition(position));
                orderList.add(item);
            }
        });



        btn_call = findViewById(R.id.btn_call);
        btn_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-4329-0963"));
                startActivity(intent);
            }
        });

        btn_touch = findViewById(R.id.btn_touch);
        btn_touch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LastActivity.class);
                intent.putStringArrayListExtra("orderList", orderList);
                startActivity(intent);
            }
        });

    }



    @Override
    protected void onResume() {
        super.onResume();
        listView.clearFocus();
        listView.clearChoices();
    }
}
