package com.example.eg00.myfirstproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    Button button;
    ArrayAdapter<String> adapter;

    FirebaseDatabase database;
    DatabaseReference myRef;
    ArrayList<String> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("refrigerator");

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(getApplication(), R.layout.listview);
        listView.setAdapter(adapter);

        // 데이터베이스에서 가져온 데이터를 담을 ArrayList 생성
        list = new ArrayList<>();

        // 데이터베이스의 내용을 읽기
        myRef.child("ingredient").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // 내용을 검색하거나 추가될 때 발생하는 이벤트
                String v = null;
                String key = dataSnapshot.getKey();
                String value = String.valueOf(dataSnapshot.getValue(Long.class));

                if (key.equals("1")) {
                    if (value.equals("0")) {
                        v = "배추김치";
                    }
                } else if (key.equals("2")) {
                    if (value.equals("0")) {
                        v = "돼지고기";
                    }
                } else if (key.equals("3")) {
                    if (value.equals("0")) {
                        v = "두부";
                    }
                } else if (key.equals("4")) {
                    if (value.equals("0")) {
                        v = "마늘";
                    }
                } else if (key.equals("5")) {
                    if (value.equals("0")) {
                        v = "대파";
                    }
                }

                if (v != null) {
                    adapter.add(v);
                    adapter.notifyDataSetChanged();
                    list.add(v);
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // 내용이 수정될 때 발생하는 이벤트
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                // 내용이 삭제되었을 때 발생하는 이벤트
                String value = dataSnapshot.getValue(String.class);
                adapter.remove(value);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // 내용이 이동될 때 발생하는 이벤트
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // 내용에 대한 오류가 발생했을 때 발생하는 이벤트
            }
        });


        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        list.clear();
    }
}
