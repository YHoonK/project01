package com.example.eg00.myfirstproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {
    Bitmap b;
    ArrayList<String> list;

    ImageButton btn_kimchi_jjigae;
    ImageButton btn_soondubu_jjigae;
    ImageButton btn_yookgaejang;
    ImageButton btn_fishjorim;
    ImageButton btn_dakdoritang;
    ImageButton btn_jeyuk_bokkeum;
    ImageButton btn_pumpkin_jjigae;
    ImageButton btn_mapatopu;
    ImageButton btn_boodae_jjigae;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btn_kimchi_jjigae = findViewById(R.id.btn_kimchi_jjigae);
        btn_kimchi_jjigae.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temp = getIntent();
                Intent intent = new Intent(getApplicationContext(), SelectMenuActivity.class);

                // 이미지 넘겨주기
                Bitmap sendBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_kimchi_jjigae);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sendBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("image", byteArray);

                // 선택메뉴 번호만 넘겨주기
                String selectedMenu = "menu1";
                intent.putExtra("menu", selectedMenu);
                list = temp.getStringArrayListExtra("list");
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });

        btn_soondubu_jjigae = findViewById(R.id.btn_soondubu_jjigae);
        btn_soondubu_jjigae.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temp = getIntent();
                Intent intent = new Intent(getApplicationContext(), SelectMenuActivity.class);

                // 이미지 넘겨주기
                Bitmap sendBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_soondubu_jjigae);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sendBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("image", byteArray);

                // 선택메뉴 번호만 넘겨주기
                String selectedMenu = "menu3";
                intent.putExtra("menu", selectedMenu);
                list = temp.getStringArrayListExtra("list");
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });

        btn_yookgaejang = findViewById(R.id.btn_yookgaejang);
        btn_yookgaejang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temp = getIntent();
                Intent intent = new Intent(getApplicationContext(), SelectMenuActivity.class);

                // 이미지 넘겨주기
                Bitmap sendBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_yookgaejang);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sendBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("image", byteArray);

                // 선택메뉴 번호만 넘겨주기
                String selectedMenu = "menu8";
                intent.putExtra("menu", selectedMenu);
                list = temp.getStringArrayListExtra("list");
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });

        btn_fishjorim = findViewById(R.id.btn_fishjorim);
        btn_fishjorim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temp = getIntent();
                Intent intent = new Intent(getApplicationContext(), SelectMenuActivity.class);

                // 이미지 넘겨주기
                Bitmap sendBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_fishjorim);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sendBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("image", byteArray);

                // 선택메뉴 번호만 넘겨주기
                String selectedMenu = "menu6";
                intent.putExtra("menu", selectedMenu);
                list = temp.getStringArrayListExtra("list");
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });

        btn_dakdoritang = findViewById(R.id.btn_dakdoritang);
        btn_dakdoritang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temp = getIntent();
                Intent intent = new Intent(getApplicationContext(), SelectMenuActivity.class);

                // 이미지 넘겨주기
                Bitmap sendBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_dakdoritang);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sendBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("image", byteArray);

                // 선택메뉴 번호만 넘겨주기
                String selectedMenu = "menu7";
                intent.putExtra("menu", selectedMenu);
                list = temp.getStringArrayListExtra("list");
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });

        btn_jeyuk_bokkeum = findViewById(R.id.btn_jeyuk_bokkeum);
        btn_jeyuk_bokkeum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temp = getIntent();
                Intent intent = new Intent(getApplicationContext(), SelectMenuActivity.class);

                // 이미지 넘겨주기
                Bitmap sendBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_jeyuk_bokkeum);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sendBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("image", byteArray);

                // 선택메뉴 번호만 넘겨주기
                String selectedMenu = "menu2";
                intent.putExtra("menu", selectedMenu);
                list = temp.getStringArrayListExtra("list");
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });

        btn_pumpkin_jjigae = findViewById(R.id.btn_pumpkin_jjigae);
        btn_pumpkin_jjigae.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temp = getIntent();
                Intent intent = new Intent(getApplicationContext(), SelectMenuActivity.class);

                // 이미지 넘겨주기
                Bitmap sendBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_pumpkin_jjigae);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sendBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("image", byteArray);

                // 선택메뉴 번호만 넘겨주기
                String selectedMenu = "menu4";
                intent.putExtra("menu", selectedMenu);
                list = temp.getStringArrayListExtra("list");
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });

        btn_mapatopu = findViewById(R.id.btn_mapatopu);
        btn_mapatopu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temp = getIntent();
                Intent intent = new Intent(getApplicationContext(), SelectMenuActivity.class);

                // 이미지 넘겨주기
                Bitmap sendBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_mapatopu);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sendBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("image", byteArray);

                // 선택메뉴 번호만 넘겨주기
                String selectedMenu = "menu9";
                intent.putExtra("menu", selectedMenu);
                list = temp.getStringArrayListExtra("list");
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });

        btn_boodae_jjigae = findViewById(R.id.btn_boodae_jjigae);
        btn_boodae_jjigae.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temp = getIntent();
                Intent intent = new Intent(getApplicationContext(), SelectMenuActivity.class);

                // 이미지 넘겨주기
                Bitmap sendBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_boodae_jjigae);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sendBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("image", byteArray);

                // 선택메뉴 번호만 넘겨주기
                String selectedMenu = "menu5";
                intent.putExtra("menu", selectedMenu);
                list = temp.getStringArrayListExtra("list");
                intent.putStringArrayListExtra("list", list);
                startActivity(intent);
            }
        });


    }
}
