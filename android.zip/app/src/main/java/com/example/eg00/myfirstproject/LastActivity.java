package com.example.eg00.myfirstproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class LastActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_last);

        Toast.makeText(getApplicationContext(), "주문이 안료되었습니다.", Toast.LENGTH_LONG).show();


    }
}
