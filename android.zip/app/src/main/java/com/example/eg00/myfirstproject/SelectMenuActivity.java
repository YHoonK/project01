package com.example.eg00.myfirstproject;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class SelectMenuActivity extends AppCompatActivity {
    ImageView imageView;
    TextView text_NecessaryIngredient;
    ListView listView;
    ArrayList<String> sendList;
    ArrayAdapter<String> adapter;

    ArrayList<String> menuIngredient;
    ArrayList<String> presentIngredient;

    FirebaseDatabase database;
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_menu);

        Intent passedIntent = getIntent();

        text_NecessaryIngredient = findViewById(R.id.text_NecessaryIngredient);

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(getApplication(), android.R.layout.simple_list_item_multiple_choice);
        listView.setAdapter(adapter);

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("information");
        // 인텐트에서 보내준 menu 번호
        String selectedMenu = passedIntent.getStringExtra("menu");

        presentIngredient = passedIntent.getStringArrayListExtra("list");

        menuIngredient = new ArrayList<>();


        // 비교해서 추가해주는 서버
        myRef.child(selectedMenu).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // 내용을 검색하거나 추가될 때 발생하는 이벤트
                boolean isDuplicate = false;
                String value = dataSnapshot.getValue(String.class);

                menuIngredient.add(value);

                for (String item : presentIngredient) {
                    if (item.equals(value)) {
                        isDuplicate = true;
                        break;
                    }
                }
                if (!isDuplicate) {
                    adapter.add(value);
                }
                adapter.notifyDataSetChanged();

                // 텍스트뷰에 필요한 재료 넣어주기
                String msg = "";
                for (int i = 0 ; i < menuIngredient.size(); i++) {
                    if (i == menuIngredient.size()-1) {
                        msg += menuIngredient.get(i);
                    } else {
                        msg += menuIngredient.get(i) + ",  ";
                    }
                }
                text_NecessaryIngredient.setText(msg);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // 내용이 수정될 때 발생하는 이벤트
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                // 내용이 삭제되었을 때 발생하는 이벤트
                String value = dataSnapshot.getValue(String.class);
                adapter.remove(value);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // 내용이 이동될 때 발생하는 이벤트
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // 내용에 대한 오류가 발생했을 때 발생하는 이벤트
            }
        });






        // 인텐트에서 보내준 이미지 파일 받아서 이미지뷰에 넣어주기
        imageView = findViewById(R.id.imageView);
        byte[] arr = getIntent().getByteArrayExtra("image");
        imageView.setImageBitmap(BitmapFactory.decodeByteArray(arr, 0, arr.length));



        sendList = new ArrayList<String>();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = String.valueOf(parent.getItemAtPosition(position));
                if (sendList.contains(item))
                    sendList.remove(item);
                else
                    sendList.add(item);

            }
        });


        sendList = new ArrayList<String>();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("ggggggg : ", "start");
                String item = String.valueOf(parent.getItemAtPosition(position));
                Log.d("ggggggg : ", item);
                if (sendList.contains(item))
                    sendList.remove(item);
                else
                    sendList.add(item);

            }
        });

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), PaymentActivity.class);
                intent.putExtra("sendList", sendList);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        sendList.clear();
        listView.clearFocus();
        listView.clearChoices();
    }
}
